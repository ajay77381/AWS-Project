# aws-code
# For Linux use:

         $ sudo yum update -y
--------> For Sql-client

         $ sudo yum install mysql -y
-------->For python and related frameworks

	 $ sudo yum install python3 -y
	 $ sudo python3 -m pip install PyMySQL
	 $ sudo python3 -m pip install boto3
	 $ sudo python3 -m pip install flask
	 
-------->For running application

         $ sudo python3 EmpApp.py

# For Ubuntu use:

         $ sudo apt-get update
	 
-------->For Sql-client

         $ sudo apt-get install mysql-client
      
-------->For python and related frameworks

         $ sudo apt-get install python3
         $ sudo apt-get install python3-flask
         $ sudo apt-get install python3-pymysql
         $ sudo apt-get install python3-boto3
     
-------->For running application

        $ sudo python3 EmpApp.py
